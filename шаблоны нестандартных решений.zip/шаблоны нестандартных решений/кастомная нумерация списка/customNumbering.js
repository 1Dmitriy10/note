// ===================================================Кастомная нумерация списка===========================================

// import { getMarker } from "./customList.js";         Подключение
// getMarker()

export function getMarker() {
    let list = [], num = 0;
    list = document.querySelectorAll(".Элемент списка");
    for (const el of list) {
        ++num;
        el.insertAdjacentHTML('afterbegin',
            `
            <span class="Любой класс">${num}</span>
            `);
    }
}