// ======================================================Сортировка списка по горизонтали===================================

// import { adaptiveCart } from "./schemItem.js";                 Подключение
// sortSchemItems()

// Смена картинки как фонового изображения при изменении положения карточек. Карточеи как "сцепка паровоза" идут друг за другом

export function adaptiveCart() {
    // Получаю картинки
    const img = document.querySelectorAll('.scheme__item-img');
    //Отслеживаю положение в ряде
    let positionX = img[0].getBoundingClientRect().top;
    // Счетчик
    let i = 0;
    // Медиазапрос
    const mediaQuery = window.matchMedia('(max-width: 880px)')
    if (mediaQuery.matches) {
        for (const el of img) {
            // Если разрешение меньше 880px всем карточкам кроме 1 и последней задаю среднее изображение
            el.src = "./img/scheme/schem__item-bg-2.png"
        }
    } else {
        for (const el of img) {
            i++
            // Если карточка в одном ряде с первой - задаю среднее изображение
            if (positionX === el.getBoundingClientRect().top) {
                el.src = "./img/scheme/schem__item-bg-2.png"
            }
            // Если карточка перешла на другую строку
            else {
                // Если это последний элемент элемент в списке и первый в новой строке, то предыдуший будет иметь промежуточное изображение
                if (el === img[img.length - 1]) {
                    img[i - 2].src = "./img/scheme/schem__item-bg-2.png"
                }
                // Если элемент не последний
                else {
                    // Переводим отслеживание на новую строку
                    positionX = el.getBoundingClientRect().top
                    // Задаем первому элементу новой строки первое изображение
                    el.src = "./img/scheme/schem__item-bg-1.png"
                    // Последнему элементу предыдущей строки задаем последнее изображение
                    img[i - 2].src = "./img/scheme/schem__item-bg-3.png"
                }
            }
        }
    }
    // Первой и последней карточки задаем соответственно первое и последнее изображение
    img[0].src = "./img/scheme/schem__item-bg-1.png"
    img[img.length - 1].src = "./img/scheme/schem__item-bg-3.png"
}

// ======================================================Сортировка списка по вертикали===================================

// import { list } from "./choisList.js";        Подключение
export function list() {
    //Получаем элементы
    const items = document.querySelectorAll('.chois__item');
    //Получаем оболочку
    const wrap = document.querySelector('.chois__item-box');
    //Номер елемента (чет/не чет)
    let i = 0;
    //Результат высоты оболочки
    let result = 0;
    //Промежуточное значение
    let x = 0;
    //Цикл по всем элементам
    for (const el of items) {
        i++
        //Если нечетные
        console.log(result)
        if (i % 2 !== 0) {
            x = el.clientHeight + 16;
            result += x;
            //Если четные
        } else if (i % 2 === 0) {
            //Если высота елемента во 2 столбце больше елемента в 1 столбце, то используем его
            if (el.clientHeight > items[i - 2].clientHeight) {
                result = result - x + el.clientHeight + 16    //16 - это отступы между эелементами
            }
        }

    }
    //Присваеваем оболочке суммарную высоту вместе с отступами
    wrap.style.cssText = `height: ${result}px`

    //Делает параллельные блоки одинаковой высоты

    //Длинна масиива
    let length = items.length;
    //Элемент на котором заканчивается 1 столбец
    let lastElementFistColumn = Math.floor(length / 2)
    //Прохожу по элементам пока 
    for (let i = 0; lastElementFistColumn < length; i++) {
        //Если высота элемента из первой колонки больше, то и элементу из второй колонки присваиваем такуе-же высоту
        if (items[i].clientHeight > items[lastElementFistColumn].clientHeight) {
            items[lastElementFistColumn].style.cssText = `height: ${items[i].clientHeight}px`
        }
        else if (items[i].clientHeight < items[lastElementFistColumn].clientHeight) {
            items[i].style.cssText = `height: ${items[lastElementFistColumn].clientHeight}px`
        }
        lastElementFistColumn++

    }
}
list()