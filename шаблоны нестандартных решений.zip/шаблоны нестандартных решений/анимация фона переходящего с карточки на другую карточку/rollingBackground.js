// ======================================================Анимация переходящего фона===================================
//Подключение import { getBlueBg } from "./animationBgBlue.js";

export function getBlueBg() {
    //все элементы
    const items = document.querySelectorAll(".srvice__content-item");
    //Всем вешаем событие
    for (const el of items) {
        el.addEventListener('mouseenter', addBg);
        el.addEventListener('mouseleave', removeBg);
    }
    //фон заходит слева направо
    function addBg(ev) {
        //первый дочерний элемент того элемента на который мы наводим(занимает всю высоту и ширину, изначально прозрачный)
        const bg = ev.target.firstElementChild
        bg.style.cssText = `
        background: #09aff4;
        transition: 0.5s;
        animation: go 0.5s forwards;`
    }
    //фон уходит слева направо
    function removeBg(ev) {
        //первый дочерний элемент того элемента с которого мы уходим
        const bg = ev.target.firstElementChild
        bg.style.cssText = `
        background: transparent;
        transition: 0.5s;
        animation: out 0.5s forwards;
        `
    }
}
getBlueBg()