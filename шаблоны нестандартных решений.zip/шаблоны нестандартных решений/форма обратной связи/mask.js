export function getInputMask() {
    let selector = document.querySelectorAll(".tel");

    let im = new Inputmask("+7 (999) 999-99-99");
    im.mask(selector);
}
getInputMask()