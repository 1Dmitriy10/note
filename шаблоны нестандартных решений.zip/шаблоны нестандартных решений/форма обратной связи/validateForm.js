//================================шаблон формы обратной================================
//ждем загрузки страницы
export function getForm() {
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.querySelectorAll(".form");
        //событие при отправке
        form.forEach(el => {
            el.addEventListener("submit", formSend);
        });
        //отправка
        async function formSend(e) {
            let id = e.target.id
            e.preventDefault();
            // переменная для ошибок в форме (вызывает функцию валидации)
            let error = formValidate(form, id);
            //если ошибок нет отправляем форму
            console.log(error)
            if (error === 0) {
                let sendForm = '';
                form.forEach(el => {
                    if (el.id == id) {
                        sendForm = el;
                    }
                })
                let formData = new FormData(sendForm);
                //отправляем форму в файл send.php
                let response = await fetch('send_mail.php', {
                    method: "POST",
                    body: formData
                });
                //если форма успешно отправлена
                let printMessage = document.querySelector(`#${sendForm.id} > .send-message > .send-message-wrap > .send-message-text`);
                let boxMessage = document.querySelector(`#${sendForm.id} > .send-message`);
                let colorBoxMessage = document.querySelector(`#${sendForm.id} > .send-message > .send-message-wrap`);

                if (response.ok) {
                    let result = await response.json();
                    printMessage.innerHTML = "";
                    printMessage.innerHTML = `${result.message}`;
                    boxMessage.classList.add("active");
                    colorBoxMessage.classList.add("_green");
                    let closeMessage = setTimeout(() => {
                        boxMessage.classList.remove("active")
                        colorBoxMessage.classList.remove("_green");
                    }, 5000
                    )
                    sendForm.reset();
                    //если произошла ошибка отпраки
                } else {
                    printMessage.innerHTML = "";
                    printMessage.innerHTML = `Ошибка отправки формы`;
                    boxMessage.classList.add("active");
                    colorBoxMessage.classList.add("_red");
                    let closeMessage = setTimeout(() => {
                        boxMessage.classList.remove("active");
                        colorBoxMessage.classList.remove("_red");
                    }, 5000
                    )
                }
                //если валидация не прошла выводим ошибку
            } else {
                printMessage.innerHTML = "";
                printMessage.innerHTML = `Ошибка отправки формы`;
                boxMessage.classList.add("active");
                colorBoxMessage.classList.add("_red");
                let closeMessage = setTimeout(() => {
                    boxMessage.classList.remove("active");
                    colorBoxMessage.classList.remove("_red");
                }, 5000
                )
            }
        }
        //функция валидации
        function formValidate(form, id) {
            let error = 0;
            form.forEach(el => {
                if (el.id == id) {
                    let idForm = el.id;

                    //все инпуты
                    let formReq = document.querySelectorAll(`#${idForm} > .form__row > ._req`);
                    for (const el of formReq) {
                        const input = el;
                        //сбрасываем ошибки инпутов
                        formRemoveError(input);
                        //если инпут имейл, то запускаем проверку имейла
                        if (input.classList.contains('_email')) {
                            if (emailTest(input)) {
                                formAddError(input)
                                error++;
                            }
                            //если инпут чекбокс
                        } else if (input.getAttribute("type") === "checkbox" && input.checked === false) {
                            formAddError(input);
                            error++
                            //если инпут пустой
                        } else {
                            if (input.value === "") {
                                formAddError(input);
                                error++
                            }
                        }
                    }
                }
            })
            return error;
        }
        //функция добавления ошибок
        function formAddError(input) {
            console.log('this')
            // input.parentElement.classList.add("_error");
            input.classList.add("_error");
        }
        //функция снятия ошибок
        function formRemoveError(input) {
            // input.parentElement.classList.remove("_error");
            input.classList.remove("_error");
        }
        //функция проверки имейла
        function emailTest(input) {
            return !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/.test(input.value);
        }
    })
}
getForm()
