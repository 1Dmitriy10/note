function loadData() {
    return new Promise((resolve, reject) => {
      // setTimeout не является частью решения
      // Код ниже должен быть заменен на логику подходящую для решения вашей задачи
      setTimeout(resolve, 2200);
    })
  }
  
  loadData()
    .then(() => {
      let preloaderEl = document.getElementById('preloader');
      preloaderEl.classList.add('hidden');
      preloaderEl.classList.remove('visible');
    });